
import '../models/palavra.dart';

final List<Palavra> palavras = [
  Palavra(texto: 'Mãe', emoji: '👩'),
  Palavra(texto: 'Pai', emoji: '👨'),
  Palavra(texto: 'Água', emoji: '💧'),
  Palavra(texto: 'Bola', emoji: '⚽'),
  Palavra(texto: 'Gato', emoji: '🐱'),
  Palavra(texto: 'Comer', emoji: '🍎'),
  Palavra(texto: 'Dormir', emoji: '😴'),
];
