
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const LeituraGlobalApp());
}

class LeituraGlobalApp extends StatelessWidget {
  const LeituraGlobalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Leitura Global',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomeScreen(),
    );
  }
}
