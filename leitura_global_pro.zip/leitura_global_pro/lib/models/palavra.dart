
class Palavra {
  final String texto;
  final String emoji;

  Palavra({
    required this.texto,
    required this.emoji,
  });
}
