
import 'package:flutter/material.dart';
import '../data/palavras.dart';
import '../widgets/palavra_card.dart';
import '../widgets/recompensa_widget.dart';
import '../services/progresso_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int indexAtual = 0;
  int pontos = 0;
  bool mostrarRecompensa = false;

  @override
  void initState() {
    super.initState();
    carregarPontos();
  }

  Future<void> carregarPontos() async {
    pontos = await ProgressoService.obterPontuacao();
    setState(() {});
  }

  Future<void> proximaPalavra() async {
    setState(() {
      mostrarRecompensa = true;
      pontos++;
    });

    await ProgressoService.guardarPontuacao(pontos);

    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      mostrarRecompensa = false;
      indexAtual = (indexAtual + 1) % palavras.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final palavra = palavras[indexAtual];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Leitura Global'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Estrelas: \$pontos',
              style: const TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30),

            PalavraCard(
              palavra: palavra.texto,
              emoji: palavra.emoji,
            ),

            const SizedBox(height: 30),

            if (mostrarRecompensa)
              const RecompensaWidget(),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 70,
              child: ElevatedButton(
                onPressed: proximaPalavra,
                child: const Text(
                  'Continuar',
                  style: TextStyle(fontSize: 24),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
