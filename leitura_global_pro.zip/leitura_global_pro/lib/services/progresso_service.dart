
import 'package:shared_preferences/shared_preferences.dart';

class ProgressoService {
  static Future<void> guardarPontuacao(int valor) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('pontuacao', valor);
  }

  static Future<int> obterPontuacao() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('pontuacao') ?? 0;
  }
}
