
import 'package:flutter/material.dart';

class PalavraCard extends StatelessWidget {
  final String palavra;
  final String emoji;

  const PalavraCard({
    super.key,
    required this.palavra,
    required this.emoji,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(25),
      ),
      child: Column(
        children: [
          Text(
            palavra.toUpperCase(),
            style: const TextStyle(
              fontSize: 42,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            emoji,
            style: const TextStyle(fontSize: 100),
          ),
        ],
      ),
    );
  }
}
