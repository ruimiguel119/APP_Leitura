
import 'package:flutter/material.dart';

class RecompensaWidget extends StatelessWidget {
  const RecompensaWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: const [
        Icon(
          Icons.star,
          size: 60,
          color: Colors.amber,
        ),
        SizedBox(height: 10),
        Text(
          'Muito Bem!',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        )
      ],
    );
  }
}
